package v1;

/**
 * A superclass to allow for future expansion in which additional forms
 * of statistics may be introduced.
 * 
 * @author myersjac
 *
 */
public class Statistic {

}